import datetime
from modules.online.steps import simulator as sem
from modules.online.types import types as tm
from modules.online.entities import sim_path as sppm
from typing import List
from tools import count as cm
from apps.network.lir import udp_other_client as uocm
from modules.online.steps import osmd_step as osm
import math
import time
if __name__ != "__main__":
    from modules.kernel import kernel_configurator as kcm


def forward_real_packets_or_retrieve_acks_for_fixed_batch(sm: sem.Simulator,
                                                          current_epoch_selected_path: sppm.SimPath) -> (List[int], List[int], sppm.SimPath):
    """
    进行真实的数据包的转发
    :return:
    """
    # 首先判断是否需要进行 retrieve
    # --------------------------------------------------------------------------------------------------------------------------------------------
    if len(sm.old_epoch_path_list) > 0:
        old_epoch_selected_path = sm.old_epoch_path_list[0]
        epoch_id, sending_time_elapsed, received_ack_counts, expected_ack_counts, retrieved = kcm.kernel_config_loader.retrieve_kernel_information_for_fixed_batch()
        if retrieved:
            # 如果当前选择进行 epoch 的获取
            sm.old_epoch_path_list.pop(0)
            sm.latest_acks_epoch = epoch_id
            sm.sim_graph.sending_elapsed_list.append(sending_time_elapsed)
            sm.sim_graph.packet_sending_rate.append(float(sm.client_detailed_info.batch_size) / (sending_time_elapsed / 1000 / 1000))
            sm.sim_graph.retrieved_timestamp_list.append(time.time())
            return received_ack_counts, expected_ack_counts, old_epoch_selected_path
        else:
            # 如果当前选择进行发送数据包
            sm.sim_graph.sending_timestamp_list.append(time.time())
    sm.old_epoch_path_list.append(current_epoch_selected_path)
    # 如果有一次没有拿上来, 那么就会等待发送包的时间, 然后进行下一次的获取, 如果获取到了可以再立马尝试进行下一次的获取
    # --------------------------------------------------------------------------------------------------------------------------------------------

    # ---------------------------------------- 走到这一步说明将所有的 ack 都取干净了, 准备进行下一个 epoch 的发送了 --------------------------------------
    # for sim_path in sm.sim_graph.available_paths:
    #     for sim_abs_link in sim_path.directed_abs_links:
    #         for retrieved_ack_epoch in sm.sim_graph.retrieved_ack_epochs:
    #             sim_abs_link.acc_backward_loss += sim_abs_link.decide_probabilities[retrieved_ack_epoch] * (sim_abs_link.weighted_accumulated_loss_m_list[-1] - sim_abs_link.weighted_accumulated_loss_m_list[retrieved_ack_epoch])
    #             sim_abs_link.acc_backward_loss += sim_abs_link.decide_probabilities[retrieved_ack_epoch] *
    #
    # for sim_path in sm.sim_graph.available_paths:
    #     for sim_abs_link in sim_path.directed_abs_links:
    #         sim_abs_link.backward_loss_list.append(sim_abs_link.acc_backward_loss)
    # ---------------------------------------- 走到这一步说明将所有的 ack 都取干净了, 准备进行下一个 epoch 的发送了 --------------------------------------

    # 进行清空的设置
    sm.sim_graph.retrieved_ack_epochs = []

    # 如果 retrieve 不回来就进行 sending
    # --------------------------------------------------------------------------------------------------------------------------------------------
    delivery_ratio_list = []
    for simDirectedPvLink in current_epoch_selected_path.directed_abs_links:
        if len(simDirectedPvLink.illegal_ratios) == 0:
            delivery_ratio_list.append(1.0)
        else:
            delivery_ratio_list.append((1 - simDirectedPvLink.illegal_ratios[-1]))

    # 进行返回
    if (sm.latest_selected_path is None) or (
            sm.latest_selected_path.description != current_epoch_selected_path.description):
        # 获取批次大小
        batch_size = sm.simulator_params.number_of_pkts_per_link * (
                len(current_epoch_selected_path.pv_routers) + 1)
        # 计算每个节点的采样大小
        counts = cm.calc_cascade_sample_counts(batch_size, delivery_ratio_list)
        # 如果当前内核路径为空, 或者当前内核路径和当前选择的路径不同
        sm.latest_selected_path = current_epoch_selected_path
        # 进行路径的下发
        kcm.kernel_config_loader.set_sec_path_mab_route_for_fixed_batch(current_epoch_selected_path,
                                                                        batch_size,
                                                                        counts)
    else:
        # 如果路径相同, 只需要进行路径的重置即可
        # 获取批次大小
        batch_size = sm.simulator_params.number_of_pkts_per_link * (
                len(current_epoch_selected_path.pv_routers) + 1)
        # 计算每个节点的采样大小
        counts = cm.calc_cascade_sample_counts(batch_size, delivery_ratio_list)
        # 进行路径的下发
        kcm.kernel_config_loader.reset_sec_path_mab_route_for_fixed_batch(batch_size, counts)

    # 进行实际的数据包的发送
    sm.client_detailed_info.batch_size = sm.simulator_params.number_of_pkts_per_link * (
            len(current_epoch_selected_path.pv_routers) + 1)
    udp_other_client = uocm.UdpOtherClient(sm.client_detailed_info)
    udp_other_client.start()
    # --------------------------------------------------------------------------------------------------------------------------------------------
    # 进行发送 epoch, relied_epoch, 选择的路径的更新
    # --------------------------------------------------------------------------------------------------------------------------------------------
    sm.sim_graph.sending_epochs.append(sm.latest_sending_epoch)
    sm.latest_sending_epoch += 1
    sm.sim_graph.relied_acks_epochs.append(sm.latest_acks_epoch)
    sm.sim_graph.selected_paths.append(current_epoch_selected_path)
    # 进行 deda 的 decide probability 的更新
    for sim_abs_link in sm.sim_graph.sim_directed_abs_links:
        sim_abs_link.decide_probabilities.append(sim_abs_link.explore_probabilities[-1])
    # --------------------------------------------------------------------------------------------------------------------------------------------
    # 按照 scheduled_list 进行更新
    # --------------------------------------------------------------------------------------------------------------------------------------------
    updated = osm.update_according_to_scheduled_list(sm, sm.latest_sending_epoch)
    # --------------------------------------------------------------------------------------------------------------------------------------------
    # 进行路径的损失值的更新
    # --------------------------------------------------------------------------------------------------------------------------------------------
    if updated or (sm.best_path is None):
        sm.best_path = osm.recalculate_score_and_find_best_path(sm)
    sm.sim_graph.best_paths.append(sm.best_path)
    # --------------------------------------------------------------------------------------------------------------------------------------------
    # 如果当前选择的路径和 best path 不一致的话, 那么 regret 进行 + 1 的操作
    # --------------------------------------------------------------------------------------------------------------------------------------------
    current_regret = current_epoch_selected_path.calculate_regret(sm.simulator_params.minimum_delivery_ratio)
    sm.sim_graph.accumulate_current_regret += current_regret
    sm.sim_graph.regret_list.append(sm.sim_graph.accumulate_current_regret / float(sm.latest_sending_epoch))
    # --------------------------------------------------------------------------------------------------------------------------------------------
    # 完成之后再检查一次
    return [], [], None


def start_fixed_batch(sm: sem.Simulator):
    # 1. 让所有的路径的概率相同 (并计算出每条边的概率)
    osm.init_all_edges_probabilities(sm)  # 这里面会将所有的链路的概率初始化为 0.5, 只进行一次

    # 2. 进入循环
    while True:
        if sm.latest_acks_epoch == sm.simulator_params.number_of_epochs:
            break

        if sm.retrieved_acks:
            # ----------------------- 根据更新后的模型进行路径的选择  -----------------------
            # 进行开始时间的定义
            start_time = datetime.datetime.now()
            # 2.0 设置每条边的当前的概率
            osm.set_current_edges_probability(sm)
            # 2.1 根据边的概率进行流分解
            path_mapping = osm.decompose_to_get_path_probabilities(sm)
            # 2.2 决策当前路径 (原代码此处注释为 2.2，应为确定本轮路径)
            current_epoch_selected_path = osm.determine_current_epoch_selected_path(sm, path_mapping)
            # 记录经过了多少时间
            determine_path_time_elapsed = (datetime.datetime.now() - start_time).total_seconds()
            # 进行list的更新
            sm.sim_graph.determine_path_time_elapsed_list.append(determine_path_time_elapsed)
            # ----------------------- 根据更新后的模型进行路径的选择  -----------------------
        else:
            current_epoch_selected_path = sm.latest_selected_path

        # 2.4.2 发送一批数据包
        if sm.running_type == tm.RunningType.RealTest:
            # 这里的 exp_counts 和 ack_counts 可能会延迟抵达
            received_ack_counts, expected_ack_counts, old_epoch_selected_path = forward_real_packets_or_retrieve_acks_for_fixed_batch(
                sm, current_epoch_selected_path)
            if len(received_ack_counts) == 0:
                sm.retrieved_acks = False
                continue
            else:
                sm.retrieved_acks = True
        else:
            raise ValueError("unsupported real or virtual type: %d", sm.running_type)

        stat_update_model_time = datetime.datetime.now()

        # 2.4.3 进行当前的计算的路径的更新
        if sm.running_type == tm.RunningType.RealTest:
            current_calculated_path = old_epoch_selected_path
        else:
            raise ValueError("unsupported real or virtual type: %d", sm.running_type)

        # 2.4.4 计算传输失败率
        directed_abs_links, directed_abs_links_mapping = current_calculated_path.get_directed_abs_links()
        for index in range(len(received_ack_counts)):
            if index == 0:
                # 当前估计的成功率
                estimated_legal_ratio = min(float(received_ack_counts[index] / expected_ack_counts[index]), 1.0)
            else:
                # 当前估计的成功率
                delivery_ratio_before = float(received_ack_counts[index - 1]) / float(
                    expected_ack_counts[index - 1])  # 84 / 100
                delivery_ratio_current = float(received_ack_counts[index]) / float(
                    expected_ack_counts[index])  # 89 / 100
                numerator = delivery_ratio_current
                denominator = delivery_ratio_before
                if denominator == 0:
                    estimated_legal_ratio = 0
                else:
                    estimated_legal_ratio = min(numerator / denominator, 1.0)

            directed_abs_links[index].illegal_ratios.append(1 - estimated_legal_ratio)

        # 未进行探测的链路的非法率为 0
        for directed_abs_link in sm.sim_graph.sim_directed_abs_links:
            if directed_abs_link.description not in directed_abs_links_mapping:
                directed_abs_link.illegal_ratios.append(0.0)

        # 记录收到的 ack 的 epoch
        sm.sim_graph.retrieved_ack_epochs.append(sm.latest_acks_epoch)

        # 2.4.5 计算无偏估计
        for directed_pv_link in sm.sim_graph.sim_directed_abs_links:
            if directed_pv_link.description in directed_abs_links_mapping:
                # illegal_ratio = directed_pv_link.illegal_ratios[epoch - 1]
                illegal_ratio = directed_pv_link.illegal_ratios[-1]
                rectified_loss = osm.calculate_rectified_loss(sm, illegal_ratio, directed_pv_link.explore_probabilities[-1])
                directed_pv_link.rectified_losses.append(rectified_loss)
                # -------------------------------- deda 算法的更新过程 --------------------------------
                retrieved_feedback_decide_prob = directed_pv_link.decide_probabilities[sm.latest_acks_epoch]
                directed_pv_link.weighted_accumulated_loss_m += retrieved_feedback_decide_prob * rectified_loss
                directed_pv_link.accumulated_loss_z += rectified_loss
                if len(directed_pv_link.weighted_accumulated_loss_m_list) < sm.latest_sending_epoch:
                    directed_pv_link.weighted_accumulated_loss_m_list.append(directed_pv_link.weighted_accumulated_loss_m)
                    directed_pv_link.accumulated_loss_z_list.append(directed_pv_link.accumulated_loss_z)
                # -------------------------------- deda 算法的更新过程 --------------------------------
            else:
                rectified_loss = 0.0
                directed_pv_link.rectified_losses.append(rectified_loss)
                # -------------------------------- deda 算法的更新过程 --------------------------------
                directed_pv_link.weighted_accumulated_loss_m += 0
                directed_pv_link.accumulated_loss_z += rectified_loss
                if len(directed_pv_link.weighted_accumulated_loss_m_list) < sm.latest_sending_epoch:
                    directed_pv_link.weighted_accumulated_loss_m_list.append(directed_pv_link.weighted_accumulated_loss_m)
                    directed_pv_link.accumulated_loss_z_list.append(directed_pv_link.accumulated_loss_z)
                # -------------------------------- deda 算法的更新过程 --------------------------------

        # 2.4.6 更新各个节点的权重
        for directed_pv_link in sm.sim_graph.sim_directed_abs_links:
            if sm.simulator_params.enable_dynamic_learning_rate:
                gap = sm.sim_graph.sending_epochs[-1] - sm.sim_graph.relied_acks_epochs[-1]
                learning_rate_modified = sm.simulator_params.learning_rate / math.pow(gap, 0.5)
                current_epoch_weight = directed_pv_link.explore_probabilities[-1] * math.exp(
                    -learning_rate_modified * directed_pv_link.rectified_losses[-1])
            else:
                current_epoch_weight = directed_pv_link.explore_probabilities[-1] * math.exp(
                    -sm.simulator_params.learning_rate * directed_pv_link.rectified_losses[-1])
            directed_pv_link.weights.append(current_epoch_weight)

        # 2.4.7 将权重重新进行投影
        source_node = sm.sim_graph.sim_abstract_nodes_mapping[
            sm.sim_graph.graph_params.source_dest_params.source]
        dest_node = sm.sim_graph.sim_abstract_nodes_mapping[
            sm.sim_graph.graph_params.source_dest_params.destination]
        osm.projection_back_to_legal_plane(sm, source_node, dest_node)

        # 获取更新模型的时间
        update_model_time_elapsed = (datetime.datetime.now() - stat_update_model_time).total_seconds()
        sm.sim_graph.update_model_time_elapsed_list.append(update_model_time_elapsed)



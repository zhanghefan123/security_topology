from typing import List, Optional
from dataclasses import dataclass


@dataclass
class RetrievedFeedback:
    epoch_id: int = 0  # 收到来自 epoch_id 的反馈
    sending_time_elapsed: int = 0  # 发送时间的延迟
    retrieved_ack_counts: Optional[List[int]] = None  # 实际收到的 ack 的数量
    expected_ack_counts: Optional[List[int]] = None  # 预计收到的 ack 的数量

    def __init__(self, epoch_id: int,
                 sending_time_elapsed: int,
                 retrieved_ack_counts: List[int],
                 expected_ack_counts: List[int]):
        self.epoch_id = epoch_id
        self.sending_time_elapsed = sending_time_elapsed
        self.retrieved_ack_counts = retrieved_ack_counts
        self.expected_ack_counts = expected_ack_counts
